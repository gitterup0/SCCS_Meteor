import { Template } from 'meteor/templating';
import './message.html';
import './like.html';
import './like.js';