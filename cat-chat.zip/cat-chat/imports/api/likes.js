import { Mongo } from 'meteor/mongo';
export const Likes = new Mongo.Collection('likes');