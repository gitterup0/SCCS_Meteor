import '../imports/ui/body.js';
import '../imports/ui/like.js';
import '../imports/startup/accounts-config.js';