import { Meteor } from 'meteor/meteor';
import '../imports/api/messages.js';
import '../imports/api/likes.js';

Meteor.startup(() => {
  // code to run on server at startup
});
